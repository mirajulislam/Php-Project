-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 26, 2018 at 06:57 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `molla_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(100) NOT NULL,
  `brand_titel` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_titel`) VALUES
(201030, 'HP'),
(201031, 'Samsung'),
(201032, 'Apple'),
(201033, 'LG'),
(201034, 'Sony'),
(201035, 'Cloth Brand'),
(201036, 'BATA');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(100) NOT NULL,
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(250) NOT NULL,
  `user_id` int(10) NOT NULL,
  `product_title` varchar(300) NOT NULL,
  `product_image` text NOT NULL,
  `qty` int(100) NOT NULL,
  `price` int(100) NOT NULL,
  `total_amount` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `p_id`, `ip_add`, `user_id`, `product_title`, `product_image`, `qty`, `price`, `total_amount`) VALUES
(11221019, 9055565, '0', 0, 'Hp Laptop Pavilion', 'hp_laptop_2.PNG', 1, 1100, 1100),
(11221020, 9055569, '0', 0, 'Mens_showes_ex', 'mens_showes1.JPG', 1, 35, 35),
(11221021, 9055568, '0', 0, 'Mens Showes', 'mens_showes.JPG', 1, 30, 30),
(11221022, 9055567, '0', 0, 'Table Light', 'lamp1.JPG', 1, 40, 40),
(11221023, 9055570, '0', 0, 'Female hilies', 'female_showes3.JPG', 1, 35, 35),
(11221024, 9055564, '0', 0, 'Hp Laptops r series', 'hp_laptop_1.PNG', 1, 1050, 1050),
(11221028, 9055561, '0', 112232104, 'Samsung Dous 2', 'samsung_S8.JPG', 1, 600, 600),
(11221029, 9055562, '0', 0, 'i phone 7', 'i7.JPG', 1, 750, 750),
(11221035, 9055566, '0', 112232104, 'Table light', 'lamp2.JPG', 1, 50, 50),
(11221037, 9055570, '0', 112232104, 'Female hilies', 'female_showes3.JPG', 1, 35, 35),
(11221038, 9055560, '0', 0, 'i phone 6', 'i6.JPG', 1, 700, 700),
(11221039, 9055562, '0', 112232104, 'i phone 7', 'i7.JPG', 1, 750, 750),
(11221040, 9055565, '0', 112232104, 'Hp Laptop Pavilion', 'hp_laptop_2.PNG', 1, 1100, 1100),
(11221041, 9055564, '0', 112232104, 'Hp Laptops r series', 'hp_laptop_1.PNG', 1, 1050, 1050),
(11221042, 9055563, '0', 112232104, ' i phone 8', 'i8.JPG', 1, 1000, 1000),
(11221043, 0, '0', 112232104, '', '', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(100) NOT NULL,
  `cat_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(60504010, 'Electronics'),
(60504011, 'Ladies Wears'),
(60504013, 'Mens Wears'),
(60504014, 'Kinds Wear'),
(60504015, 'Furniures'),
(60504016, 'Home Applications'),
(60504017, 'Electronices Gadgets');

-- --------------------------------------------------------

--
-- Table structure for table `customer_order`
--

CREATE TABLE `customer_order` (
  `id` int(100) NOT NULL,
  `uid` int(100) NOT NULL,
  `pid` int(100) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `p_price` int(100) NOT NULL,
  `p_qty` int(100) NOT NULL,
  `p_status` varchar(300) NOT NULL,
  `trx_id` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(100) NOT NULL,
  `product_brand` int(100) NOT NULL,
  `product_cat` int(100) NOT NULL,
  `product_title` varchar(300) NOT NULL,
  `product_price` int(100) NOT NULL,
  `product_desc` text NOT NULL,
  `product_image` text NOT NULL,
  `product_keywords` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_brand`, `product_cat`, `product_title`, `product_price`, `product_desc`, `product_image`, `product_keywords`) VALUES
(9055560, 201032, 60504010, 'i phone 6', 700, 'i phone 6 64GB ', 'i6.JPG', 'Apple mobile Electronices'),
(9055561, 201031, 60504010, 'Samsung Dous 2', 600, 'Samsung Dous 2', 'samsung_S8.JPG', 'samsung mobile electronices'),
(9055562, 201032, 60504010, 'i phone 7', 750, 'i phone 7 128 GB', 'i7.JPG', 'Apple mobile Electronices'),
(9055563, 201032, 60504010, ' i phone 8', 1000, 'i phone 8 128 GB', 'i8.JPG', 'Apple mobile Electronices'),
(9055564, 201030, 60504010, 'Hp Laptops r series', 1050, 'Hp Balck And Grck combination Laptop', 'hp_laptop_1.PNG', 'hp laptop'),
(9055565, 201030, 60504010, 'Hp Laptop Pavilion', 1100, 'Hp Laptob balck and gray combination', 'hp_laptop_2.PNG', 'Hp Laptop pavilion'),
(9055566, 201035, 60504010, 'Table light', 50, 'Table Lamp Light', 'lamp2.JPG', 'Electronices Table Lamp Light'),
(9055567, 201035, 60504010, 'Table Light', 40, 'Table Light', 'lamp1.JPG', 'Electronices Light'),
(9055568, 201036, 60504013, 'Mens Showes', 30, 'Bata Mens Showes', 'mens_showes.JPG', 'Bata Shows mens '),
(9055569, 201036, 60504013, 'Mens_showes_ex', 35, 'Mens Showes very exclusive', 'mens_showes1.JPG', 'Bata Shows mens '),
(9055570, 201036, 60504011, 'Female hilies', 35, 'Bata Hilies', 'female_showes3.JPG', 'Bata Female Showes'),
(9055571, 201036, 60504011, 'Kinds_female_juta', 20, 'Bata Female Juta', 'lady_kinds_shows_1.JPG', 'Bata Shows Kinds Ledes');

-- --------------------------------------------------------

--
-- Table structure for table `received_payment`
--

CREATE TABLE `received_payment` (
  `id` int(100) NOT NULL,
  `uid` int(100) NOT NULL,
  `pid` int(100) NOT NULL,
  `amount` int(100) NOT NULL,
  `trx_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(300) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`) VALUES
(112232101, 'Miraj', 'Islam', 'mirajulislam5746@gmail.com', 'miraj5746', '01780285746', 'Dhaka Framgate', 'Rajbari , Barobakpur'),
(112232102, 'Raj ', 'Islam', 'johnsmith@gmail.com', 'c5d779c8bd139ac4b5f93fb217d5a07a', '01952627993', 'Dhaka', 'Rajbari'),
(112232104, 'Miraj', 'Islam', 'mirajulsialm7993@gmail.com', '25f9e794323b453885f5181f1b624d0b', '01780285746', 'Rajbari', 'Dhaka');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `customer_order`
--
ALTER TABLE `customer_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `received_payment`
--
ALTER TABLE `received_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11221044;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60504018;
--
-- AUTO_INCREMENT for table `customer_order`
--
ALTER TABLE `customer_order`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9055572;
--
-- AUTO_INCREMENT for table `received_payment`
--
ALTER TABLE `received_payment`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112232105;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
